// get a refrence to the canvas and its context
var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
// display the scores
var scorecmt1 = hits-4;
var scorecmt2 = hits-6;
scorecmt1.innerHTML=+scorecmt1;
scorecmt2.innerHTML=+scorecmt2;
var hits = 0;
// set timer
var gameOver = false;
var count = 100;
var counter = setInterval(timer, 1000);
// set canvas to equal window size
window.addEventListener('resize', resizeCanvas, false);
// set a collision <range>
var MIN_COLISION_RANGE = 100
// newly spawned objects start at Y=25
var spawnLineY = 25;

// spawn a new object every 1500ms
var spawnRate = 1500;

// when was the last object spawned
var lastSpawn = -1;

// this array holds all spawned object
var objects = [];

// save the starting time (used to calc elapsed time)
var startTime = Date.now();
const mouse = {x :0,y :0, clicked : false};

function mouseClickEvent(event){
    mouse.x = event.offsetX;
    mouse.y = event.offsetY;
    mouse.clicked = true;
}
canvas.addEventListener("click",mouseClickEvent);

if(mouse.clicked){
    object.splice(i, 1);
    mouse.clicked = false; /// clear the clicked flag
}
// points is {x,y}
// circle is {x,y,r} where r is radius
// returns true if point touches circle
function isPointInCircle(point,circle){
     return Math.hypot(point.x - circle.x, point.y - circle.y) <= circle.r;
}
// start animating
animate();


function resizeCanvas() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;

            /**
             * Your drawings need to be inside this function otherwise they will be reset when 
             * you resize the browser window and the canvas goes will be cleared.
             */
    }
function spawnRandomObject() {

    // select a random type for this new object
    var t;

    // About Math.random()
    // Math.random() generates a semi-random number
    // between 0-1. So to randomly decide if the next object
    // will be A or B, we say if the random# is 0-.49 we
    // create A and if the random# is .50-1.00 we create B
    var random;
    random = Math.random();
    if (random < 0.75 && random > .50) {
        t = "red";
    } else if (random > .75) {
        t = "blue";
    } else if (random < .50 && random > .25) {
        t = "purple"
    } else if (random < .25) {
        t = "green"
    }

    // create the new object
    var object = {
    
        // set this objects type
        type: t,
        // set x randomly but at least 15px off the canvas edges
        x: Math.random() * (canvas.width - 30) + 15,
        // set y to start on the line where objects are spawned
        y: spawnLineY,
        downspeed: Math.floor((Math.random() * 100) + 5)/100,
        radius: Math.floor((Math.random() * 175) + 5),
        
    }

    // add the new object to the objects[] array
    objects.push(object);
}
// the code to make the circle disappear would go here

	

function animate() {

    // get the elapsed time
    var time = Date.now();
	
    // see if its time to spawn a new object
    if (time > (lastSpawn + spawnRate)) {
        lastSpawn = time;
        spawnRandomObject();
    }
	
    // request another animation frame
    requestAnimationFrame(animate);

    // clear the canvas so all objects can be 
    // redrawn in new positions
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // draw the line where new objects are spawned
    ctx.beginPath();
    ctx.moveTo(0, spawnLineY);
    ctx.lineTo(canvas.width, spawnLineY);
    ctx.stroke();
    // move each object down the canvas
    for (var i = 0; i < objects.length; i++) {
    		if(mouse.clicked){
    		objects.splice(i, 1);
    		mouse.clicked = false; /// clear the clicked flag
			}
        	var object = objects[i];
        	object.y += object.downspeed;
        	ctx.beginPath();
        	ctx.arc(object.x, object.y, object.radius, 0, Math.PI * 2);
        	ctx.closePath();
        	ctx.fillStyle = object.type;
        	ctx.fill();
    }

}
// assuming canvas is already defined and references an DOM canvas Element



resizeCanvas();

var scorecmt1 = hits-4;
var scorecmt2 = hits-6;
scorecmt1.innerHTML=+scorecmt1;
scorecmt2.innerHTML=+scorecmt2;
var hits = 0;
var gameOver = false;
var count = 100;
var counter = setInterval(timer, 1000);
// set starting height
var y1 = (Math.random() * 175) + 25 ;
var y2 = (Math.random() * 175) + 25 ;
var y3 = (Math.random() * 175) + 25 ;
//set starting left/right
var x1 = Math.random() * 150;
var x2 = Math.random() * 300;
var x3 = Math.random() * 80;
// execute move command every second
setTimeout("pop()", 0);
setTimeout("pop2()",0);
setTimeout("pop3()",0);


function pop() {
	//set speed at which object falls
  y1 += 150;
  if (count > 0){
	$(".mole").css("opacity", 1);
  }else{
	$(".mole").css("opacity", 0);
  }
  $(".mole").css("backgroundImage","url('mole.png')");
  $(".mole").css({
  // y to be away from the top, and x to be away from the right
    top: y1,
    right: x1
  });
  if(count > 0){
	setTimeout("pop()", 1000);
  }
  // if the object gets less than 200 pixels away, send it back to the top 
  // and give it a new x coordinate
  if (y1 >= ($( window ).height())-200){
  	y1 = 20;
  	x1 = Math.random() * 150;
  }
}
function pop2() {
  y2 += 100;
  if (count > 0){
	$(".mole2").css("opacity", 1);
  }else{
	$(".mole2").css("opacity", 0);
  }
  
  $(".mole2").css("backgroundImage","url('mole.png')");
  $(".mole2").css({
    top: y2,
    left: x2
  });
  if(count > 0){
	setTimeout("pop2()", 800);
  }
  if (y2 >= ($( window ).height())-200){
  	y2 = 20;
  	x2 = Math.random() * 150;
  }
  
}
function pop3() {
  
  y3 += 50;
  if (count > 0){
	$(".mole3").css("opacity", 1);
  }else{
	$(".mole3").css("opacity", 0);
  }
  
  $(".mole3").css("backgroundImage","url('mole.png')");
  $(".mole3").css({
    top: y3,
    right: x3
  });
  if(count > 0){
	setTimeout("pop3()", 500);
  }
  if (y3 >= ($( window ).height())-200){
  	y3 = 20;
  	x3 = Math.random() * 150;
  }
  
}

$('.mole').click(function() {
	// disable clicking after game ends
  if (gameOver) return;
  //display picture after mole is clicked on
  $(".mole").css("backgroundImage","url('after.png')");
  //add points
  $("#score").html(hits=hits+4);
  // send back to top and generate new horizontal coordinate
  y1 = 20;
  x1 = Math.random() * 150;
});
$('.mole2').click(function() {
  if (gameOver) return;
  $(".mole2").css("backgroundImage","url('after.png')");
  $("#score").html(hits=hits+3);
  y2 = 20;
  x2 = Math.random() * 150
});
$('.mole3').click(function() {
  if (gameOver) return;
  $(".mole3").css("backgroundImage","url('after.png')");
  $("#score").html(hits=hits+2);
  y3 = 20;
  x3 = Math.random() * 150;
});

$('button').click(function() {
  count = 30;
  hits = 0;
  $("#score").html(hits);
  gameOver = false;
});

function timer() {
  if (count <= 0) {
	$("#timer").html(0);
	yest = hits-2;
	if (count == 0){
		// $(".mole").css("opacity", 0);
		// $(".mole2").css("opacity", 0);
		secure.style.display="none";
		score.style.display="none";
		$("#timer").css("opacity", 0);
		$("#score").css("opacity", 0);
		swal(
		{title: "Congratulations!",
	  text: "Your score:<b>"+ hits +" 👍 </b><br> You beat yesterday's score of <b>"+  yest +"</b><br>🎉 🎉 🎉 <br><br>Please select the <b>Okay</b> button below to view today's special prize for "+getURLParameter("city")+" residents.",
	  imageUrl: "fireworks.gif",
	  confirmButtonText: "Okay",
		html:true},
		function(){
		whole.style.display="";
		});
		count = -1;
	}
	clearInterval();
    return;
  }
  $("#timer").html((count<10?"0:0":"0:")+count--);
}